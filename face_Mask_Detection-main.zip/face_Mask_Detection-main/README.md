# CSEA3_TeamCoders_COM-511
Teacher Incharge : Mr. Arjun Puri

Project : Face Mask Detection System

# Team Memeber

Mayank Chib    | 2020a1r174 </br>
Ankush Kumar   | 2020a1r157 </br>
Gulshan Sharma | 2020a1r172 </br>
Sahil Manni    | 2020a1r174 </br>

Data Set Used : https://drive.google.com/drive/folders/1lyzmmqELR3pzfbo_JH-6RqYfx43U91S1?usp=sharing

Basic Face Detector: Haar Cascades https://drive.google.com/file/d/1ANsL7Dnh3zlhty2S9Q9UUBk8ltJAT2Kf/view?usp=sharing
